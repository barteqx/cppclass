#include "map.h"

int main () {
    std::cout << frequencytable(std::vector<std::string>({"AA", "tHiS", "aA", "Aa", "aa", "this", "THIS"}));

    hash h;
    std::cout << h("ABCd") << " " << h("cbad") << "\n";
    equals e;
    std::cout << e("xxxDFg", "XXXdfG") << "\n";

    std::vector<std::string> words = readfile("book");
    
    auto table =  frequencytable(words);
    std::cout << "psychedelic: " << table["psychedelic"] << std::endl;
    std::string top_word;
    unsigned int max_occ = 0;
    for( auto p = table.begin(); p != table.end(); ++p ) {
        if(p->second > max_occ) {
            max_occ = p->second;
            top_word = p->first;
        }
    }
    std::cout << "Word with most occurrences: " << top_word << " " << max_occ << std::endl;
    return 0;
}
