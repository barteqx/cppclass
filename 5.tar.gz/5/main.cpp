
#include "tree.h"


int main( int argc, char* argv [ ] )
{
	   tree t1( std::string( "x" ));
	   tree t2( std::string( "50" )); 
	   tree t3 = tree( std::string( "+" ), { t1, t2 } );
	   tree t4 = tree( std::string( "/" ), { t2, t3 } ); 
	   tree t5 = diff(t4, std::string( "*" ));
	   std::cout << "differetiation" << std::endl;
	   std::cout << t4 << std::endl;
	   std::cout << t5 << std::endl;
}


