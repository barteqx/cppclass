#include <iostream>
#include "stack.h"
#include <cstdio>

int main() {

	stack s1;

	s1.push(111);
	const stack s2 = new stack(s1);
	double& i = s1.top();
	double j = s2.top();
	i = 3;
	j = 3;
	std::cout << s1 << std::endl;
	std::cout << s2 << std::endl;
	return 0;
}